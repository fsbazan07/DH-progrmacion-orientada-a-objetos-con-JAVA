package clase_11_asinc_mesa3;

public class Nave extends Objeto {
    private double velocidad;
    private int vida;

    public Nave (int x, int y, char direccion, double velocidad) {
        super(x, y, direccion);
        this.velocidad=velocidad;
    }
    public void girar (char direccion){

    }
    public void restaVida(int valor) {

    }
    @Override
    public void irA (int x, int y, char direccion){
        System.out.println(x + y + direccion);
    }
}
