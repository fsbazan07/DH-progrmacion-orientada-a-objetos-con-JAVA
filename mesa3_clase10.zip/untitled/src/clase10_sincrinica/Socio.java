package clase10_sincrinica;

public class Socio {
    private String numeroSocio;
    private String nombre;
    private Double cuotaMensual;
    private String actividad;

    public socio (String numero, String nombre, String actividad, Double cuota) {
        numeroSocio=numero;
        this.nombre=nombre;
        this.actividad= actividad;
        cuotaMensual=cuota;
    }

    public Double costoMensual() {
        return cuotaMensual;
    }
}
