package clase10_sincrinica;

public class SocioHabiltado extends Socio {
    private Double costoPileta;
    private boolean habilitado;

    public SocioHabiltado (String numero, String nombre, String actividad, Double cuota, Double costoIngreso){
        super(numero,nombre, actividad, cuota);
        costoPileta=costoIngreso;
    }
    @Override
    /*override es para sobreescritura*/

    public Double costoMensual(){
        Double costoTotal=getCuotaMensual();
        if (habilitado){
            costoTotal+=costoPileta;
    }
        return costoTotal;
}
