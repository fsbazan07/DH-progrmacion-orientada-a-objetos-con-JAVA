package clase_11_asinc_mesa3;

public class Asteroide extends Objeto {
    private int lession;

    public Asteroide(int x, int y, char direccion, int lession) {
        super(x, y, direccion);
        this.lession = lession;
    }

    @Override
    public void irA (int x, int y, char direccion){
        System.out.println(x + y + direccion);
    }
}
