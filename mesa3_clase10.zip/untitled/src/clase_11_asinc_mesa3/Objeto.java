package clase_11_asinc_mesa3;

public class Objeto {
    private int posx;
    private int posy;
    private char direccion;

    public Objeto (int x, int y, char direccion) {
        posx=x;
        posy=y;
        this.direccion=direccion;
    }
    public void irA (int x, int y, char direccion){
        }

}
