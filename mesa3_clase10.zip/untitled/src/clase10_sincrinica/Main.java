package clase10_sincrinica;

public class Main {
    public static void main (String[] args){
        Socio socio1 = new Soci;
    }
}
